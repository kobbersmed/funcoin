"""
normcap

An python package for doing Functiontal Connectivity Integrative Normative Modelling.
"""

__author__ = 'Janus R. L. Kobbersmed'